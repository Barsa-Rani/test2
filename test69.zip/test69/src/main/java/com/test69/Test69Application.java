package com.test69;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test69Application {

	public static void main(String[] args) {
		SpringApplication.run(Test69Application.class, args);
	}

}
