package com.test69;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test69ApplicationTests {

	@Test
	void contextLoads() {
	}

}
